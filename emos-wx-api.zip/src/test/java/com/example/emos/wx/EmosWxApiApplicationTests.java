package com.example.emos.wx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmosWxApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
