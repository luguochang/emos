package com.example.emos.wx.controller.form;

import io.swagger.annotations.ApiModel;
import lombok.Data;
@Data
@ApiModel
public class SearchContactForm {
    private String name;
}
